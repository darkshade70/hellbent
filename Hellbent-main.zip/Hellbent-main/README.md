# Playable Game Demo
 
Hellbent is finished! Please check out the game here: https://oscosan.itch.io/hellbent-full-demo

Thank you to our main group of QA testers:<br />
Tony Fu<br />
Azeem Khan<br />
Anthony Le<br />
Kenneth Lee<br />
Jason Tang<br />
Lucas Wong

